//
//  MMRuntimeIvarModel.m
//  CarLoan
//
//  Created by sml on 16/6/25.
//  Copyright © 2016年 sml. All rights reserved.
//

#import "MLDatabaseRuntimeIvar.h"

@implementation MLDatabaseRuntimeIvar

@end
